<?php
	
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "pokemon2";

	$connection = new mysqli($servername, $username, $password, $dbname);
	
?>