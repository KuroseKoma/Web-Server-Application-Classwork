<div class='row'>
				<div class='col-12 Head2'>
					<img src='images/pikachu.png' height='100px'>
				</div>
		</div>
		<div class='row'>
				<nav class="navbar navbar-expand-sm bg-light">

	  <!-- Links -->
	  <ul class="navbar-nav">
	    <li class="nav-item">
	      <a class="nav-link" href="read.php">Home</a>
	    </li>
	    <li class="nav-item">
	      <a class="nav-link" href="create.php">Add a Pokemon</a>
	    </li>
	  </ul>

</nav>

		</div>
